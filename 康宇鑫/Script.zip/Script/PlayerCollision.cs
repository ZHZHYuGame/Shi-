using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

public class PlayerCollision : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.tag=="Sphere")
        {
            Debug.Log("��ײ");
            other.gameObject.GetComponent<Renderer>().material.color = Color.red;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
