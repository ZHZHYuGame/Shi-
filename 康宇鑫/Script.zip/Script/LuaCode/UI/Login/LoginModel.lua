--登录功能数据层
local loginModel=BaseClass("loginModel")
--数据层初始化
function loginModel:__init()
    
end
--设置当前的记忆账号
function loginModel:SetAccount()
   
end
--设置当前的记忆账号密码
function loginModel:SetPassWord()
    
end
--获取当前的记忆账号
function loginModel:GetAccount()
   
end
--获取当前的记忆账号密码
function loginModel:GetPassWord()
    
end

return loginModel