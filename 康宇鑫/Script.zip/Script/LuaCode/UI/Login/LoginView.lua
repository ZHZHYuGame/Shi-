local loginView=BaseClass("loginView")
--初始化设置组件等
function loginView:__init(prefebObj)
    self.gameObject=prefebObj
    --组件获取
    self.input_Account=self.gameObject.transform:Find("Input_Account"):GetComponent("InputField")
    self.input_Password=self.gameObject.transform:Find("Input_Password"):GetComponent("InputField")
    --登录按钮
    self.btn_GoGame=self.gameObject.transform:Find("Button"):GetComponent("Button")
    --Toggle 记住密码
    self.toggle_passwordRemember=self.gameObject.transform:Find("Toggle_PasswordRemember"):GetComponent("Toggle")
end
--点击按钮跟请求服务器进入游戏
function loginView:GOGame()
    
end
--UI功能的事件注册
function loginView:AddListeren()
   -- self.btn_GoGame.onClick:AddListeren(self.GOGame)
end
--登录游戏
function loginView:LoginGame()
    
end
return loginView