--登录功能的逻辑控制脚本
local loginController=BaseClass("loginController")
--初始化逻辑相关数据
function loginController:__init()
    self:AddEventListeren()
    self:NetEventListeren()
end
function loginController:PasswordRemenber(txt)
    self.view.input_Password.text=txt
end
--注册客户端之间交互事件
function loginController:AddEventListeren()
    self.view.btn_GoGame.onClick:AddListener(function()
        
    end)
    self.view.toggle_passwordRemember.onValueChanged:AddListener(function(value)
       self:loginController("111")
    end)
end

--登录结果处理（来自服务器的网络消息）
function loginController:LoginHandle1()
    --通过消息的结果来判断是否登录成功
    --成功、进入游戏
    --失败、提示错误信息
end
--注册网络功能交互事件
function loginController:NetEventListeren()
   
    MessagerController:AddListener(NetMessageID.S2C_Login,self.LoginHandle1)
end
return loginController  