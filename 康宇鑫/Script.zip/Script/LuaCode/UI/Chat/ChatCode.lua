local chatCode=BaseClass("chatCode",UBase)
function chatCode:__init()
    
end
return chatCode 
