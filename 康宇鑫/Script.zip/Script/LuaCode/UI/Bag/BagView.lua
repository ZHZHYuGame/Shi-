local bagView=BaseClass("bagView")

function bagView:__init(prefabObj)
    self.gameObject=prefabObj
    --背包格子父级
    self.BagItemRoot=self.gameObject.transform:Find("Scroll View/Viewport/BagItemRoot")
    --全部按钮
    self.btn_all=self.gameObject.transform:Find("BtnRoot/Button_All"):GetComponent("Button")
    self.btn_equip=self.gameObject.transform:Find("BtnRoot/Button_Equip"):GetComponent("Button")
    self.btn_drug=self.gameObject.transform:Find("BtnRoot/Button_Drug"):GetComponent("Button")
    self.btn_box=self.gameObject.transform:Find("BtnRoot/Button_Box"):GetComponent("Button")
    self.btn_close=self.gameObject.transform:Find("Button_Close"):GetComponent("Button")
end

return bagView