local bagModel=BaseClass("bagModel")
--背包数据层
--1.背包数据层的初始化（显示）
--2.背包数据的增加
--3.背包数据的变化
--4.背包数据的删除

--背包数据初始化
function bagModel:__init()
    self.baglist=PlayerDataManager:GetBagData()
    local configManager=CS.ConfigManager()
    self.list = configManager:ReadJson()
    self.BagCell=30
end
function bagModel:OnEnable()
    --角色的缓存里取背包的显示数据
    self.baglist=PlayerDataManager:GetBagData()
end
--背包添加物品数据
function bagModel:BagAddData(gData)
    
end
function bagModel:BagUpdataData()
    
end
function bagModel:AddListener()
    
end
return bagModel