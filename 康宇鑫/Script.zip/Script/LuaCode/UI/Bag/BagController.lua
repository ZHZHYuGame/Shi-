local bagController=BaseClass("bagController")

function bagController:InitBagItem()
    print(self.model.BagCell)
    for i = 1, self.model.BagCell do
        local item=GameObject.Instantiate(Resources.Load("BagItem"),self.view.BagItemRoot.transform )
        if i<self.model.list.Count then
            item=require("UI/Bag/BagViewItem").New(self.model.list[i],item)
        else
            item=require("UI/Bag/BagViewItem").New(nil,item)
        end
    end
    
end
function  bagController:__init(...)
    --向服务器请求背包数据

end

function bagController:ClientAddListener()
    if self.model.list~=nil then
        self:InitBagItem()
    end
    self.view.btn_all.onClick:AddListener(function()
        print("点击了全部按钮")
    end)

    MessagerController:AddListeren(ClientSysytemEvent.ClientToClient1,function()
        print("客户端监听消息1...Client")
    end)

end
function bagController:Bag_Add_ViewShow()
    
end
--背包添加物品逻辑处理
function bagController:Bag_Add_Handle(gData)
    --添加一个物品信息
    local goodDtat=gData
    --1.数据层已经刷新添加的物品到整体数据里
    self.model:BagAddData(gData)
    --2.通知View层显示出来，通过self.view拿到相关的组件，进行赋值
    self.view:BagAddViewShow()
end
--背包删除物品逻辑处理
function bagController:Bag_Del_Handle()
    
end
--背包刷新物品逻辑处理
function bagController:Bag_Updata_Handle()
    
end
--背包整理物品逻辑处理
function bagController:Bag_Clean_Handle()
    
end
function  bagController:NetEventListener()
    MessagerController:AddListeren(NetMessageID.S2C_Bag_Add,Bag_Add_Handle)
    MessagerController:AddListeren(NetMessageID.S2C_Bag_Del,Bag_Del_Handle)
    MessagerController:AddListeren(NetMessageID.S2C_Bag_Updata,Bag_Updata_Handle)
    MessagerController:AddListeren(NetMessageID.S2C_Bag_Clean,Bag_Clean_Handle)
end

function  bagController:__initFinish()
    self:ClientAddListener()
    self:NetEventListener()
    --初始化组件View层的第一次显示背包列表
end
return bagController