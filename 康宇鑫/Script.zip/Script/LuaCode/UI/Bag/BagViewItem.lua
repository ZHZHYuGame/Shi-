local bagViewItem = BaseClass("bagViewItem")
local function BeginDragHandel(pointerDrag)
    if(pointerDrag.gameObject.transform:Find("icon"):GetComponent("Image").sprite~=Resources.Load("icon/bg_道具",typeof(CS.UnityEngine.Sprite)))  then
    if moveImg==nil then 
        moveImg=GameObject.Find("UIRoot/TipsLayer/MoveImg") 
        moveImg:SetActive(true)
    else
        moveImg:SetActive(true)
    end
    moveImg:GetComponent("Image").sprite=pointerDrag.gameObject.transform:Find("icon"):GetComponent("Image").sprite
    start= pointerDrag.gameObject.transform:Find("icon"):GetComponent("Image")
    start.sprite=pointerDrag.gameObject.transform:Find("icon"):GetComponent("Image").sprite
    pointerDrag.gameObject.transform:Find("icon"):GetComponent("Image").sprite=Resources.Load("icon/bg_道具",typeof(CS.UnityEngine.Sprite))
    end
end
local function DragHandel(pointerDrag)
    print("拖拽中")
    moveImg.transform.position=Input.mousePosition
end 
local function EndDragHandel(pointerDrag)
    print("结束拖拽")
    if(pointerDrag.gameObject.transform:Find("icon"):GetComponent("Image")~=nil) then
        start.sprite=pointerDrag.gameObject.transform:Find("icon"):GetComponent("Image").sprite
        pointerDrag.gameObject.transform:Find("icon"):GetComponent("Image").sprite=moveImg:GetComponent("Image").sprite
        --moveImg:GetComponent("Image").sprite=Resources.Load("icon/bg_道具",typeof(CS.UnityEngine.Sprite))
        
    end
     moveImg:SetActive(false)
end
function bagViewItem:__init(obj,item)
    data=obj
    self.gameObject=item
    if obj~=nil then
        self.gameObject.transform:Find("icon/Name").gameObject:GetComponent("Text").text=obj.name
        self.gameObject.transform:Find("icon/Num").gameObject:GetComponent("Text").text=obj.quality
        self.gameObject.transform:Find("icon").gameObject:GetComponent("Image").sprite=Resources.Load("icon/"..obj.icon,typeof(CS.UnityEngine.Sprite))
    else
        self.gameObject.transform:Find("icon").gameObject:GetComponent("Image").sprite=Resources.Load("icon/bg_道具",typeof(CS.UnityEngine.Sprite))
    end

    UIEventListener.AddObjEvent(self.gameObject):AddEventListeren(LuaEventTriggerType.BeginDrag,BeginDragHandel)
    UIEventListener.AddObjEvent(self.gameObject):AddEventListeren(LuaEventTriggerType.Drag,DragHandel)
    UIEventListener.AddObjEvent(self.gameObject):AddEventListeren(LuaEventTriggerType.EndDrag,EndDragHandel)
end
return bagViewItem
