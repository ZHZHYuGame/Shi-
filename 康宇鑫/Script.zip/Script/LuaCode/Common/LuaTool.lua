LuaTool={}
--闭包绑定
function LuaTool:Bind(self,func,...)
    assert(self==nil or typeof(self)=="table")
    assert(func~=nil and typeof(func)=="function")
    local params=nil
    if self==nil then
        params=SafePack(...)
    else
        params=SafePack(self,...)
    end
    return function (...)
        local args=ConcatSafePack(params,SafePack(...))
        func(SafeUnpack(args))
    end
end
return LuaTool  