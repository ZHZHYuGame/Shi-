--网络消息id
NetMessageID={
    --登录模块
    C2S_Login=101,
    S2C_Login=102,
    
    --背包模块
    --C2S_Bag_Info=103,--请求背包数据
    --C2S_Bag_Add=103,

    S2C_Bag_Add=104,
    C2S_Bag_Del=105,
    S2C_Bag_Del=106,
    C2S_Bag_Updata=107,
    S2C_Bag_Updata=108,
    C2S_Bag_Clean=109,
    S2C_Bag_Clean=110,
}