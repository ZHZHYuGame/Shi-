local uiBase=BaseClass("uiBase")
function uiBase:Show()
    print("Base类Show方法调用")
end
function uiBase:Close()
    
end
return uiBase   