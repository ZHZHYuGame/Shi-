--模拟对象
local uiManager = BaseClass("uiManager")
local uiName="UIManager"
uiManager.uiName="uiManager"
function uiManager:__init()
    print("UI框架的构造执行")
    --UI字典管理
    self.UIDict = {} 
    --UI打开顺序记忆栈
    self.UIStacj={}
    --UI父级Canvas
    self.canvasParent=GameObject.Find("Canvas")
end

--获取需要的Canvas层级
function uiManager:GetLayerToCanvas(layer)
    return GameObject.Find(layer)
end
--动态参数：确保能够兼容不同类型的参数，多个参数
--Lua ... ==C# params[] object
function uiManager:OpenUI(id,...)
    --self.uiName="UIMgrInstance"
    --print("self=",self,"id=",id);

    --1.加载UI预制体
    if self.UIDict[id]==nil then
        -- --加载对应的UI预制体
        -- local uiPrefab=GameObject.Instantiate(Resources.Load(UI_Prefeb_Path_Title..id),self.canvasParent.transform)
        -- --对应UI功能的脚本加载 Model/View/Controller
        -- local loginController=require("UI/"..id.."/"..id.."Controller")
        -- local loginModel=require("UI/"..id.."/"..id.."Model")
        -- local loginView=require("UI/"..id.."/"..id.."View")
        -- --对应UI脚本注册预制体绑定
        -- loginController.view=loginView.New(uiPrefab)
        -- loginController=loginController.New()
        -- loginController.Model=loginModel.New()
        -- --UI所处于的显示层
        -- --加载对应UI的Lua Code
        -- self.UIDict[id]=uiPrefab
        local config=require ("UI/"..id.."/"..id.."Config")
        --对应UI功能模块预制体加载
        local uiPrefab=GameObject.Instantiate(Resources.Load(UI_Prefeb_Path_Title..config.PrefabName),self:GetLayerToCanvas(config.Layer).transform)
        --MVC脚本模块导入
        config.ControllerCode=config.ControllerCode.New(...)
        config.ControllerCode.model=config.ModelCode.New()
        config.ControllerCode.view=config.ViewCode.New(uiPrefab)
        --MVC脚本模块导入完成
        config.ControllerCode:__initFinish()
        --加载对应UI的Lua Code
        self.UIDict[id]=config
    end
    
end

function uiManager:GetUI(id)
    
end

function uiManager:CloseUI(id)
    
end


return uiManager

