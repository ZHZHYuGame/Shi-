local managerBase = {}  
function managerBase:MessageControll()
    
end
function managerBase:AddEventListeren()
    
end
return managerBase  