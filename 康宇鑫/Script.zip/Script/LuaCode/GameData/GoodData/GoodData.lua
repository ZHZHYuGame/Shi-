local goodData=BaseClass("goodData")
function goodData:__init(...)
    local parTab={...}
    self.goodid=parTab[1]
    self.goodName=parTab[2]
    self.goodType=parTab[3]
    self.goodQuality=parTab[4]
    self.goodIcon=parTab[5]
end
return goodData 

