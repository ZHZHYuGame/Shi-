--缓存角色的一部分游戏数据
local playerDataManager={}
function playerDataManager:__init()
    self.BagList = {}
    self.BagEquipList = {}
    self.MedicinalList={}
    self.SkillList = {}
    self.MailList={}
end
function playerDataManager:SetBagData(list)
    self.BagList = list
end
function playerDataManager:GetBagData()
    return self.BagList
end
--在缓存中添加物品
function playerDataManager:AddBagData(gData)
    table.insert(self.BagList, gData)
end
--在缓存中删除物品
function playerDataManager:DelBagData(gridID)
    for index, value in ipairs(self.BagList) do
        if index==gridID then
            table.remove(self.BagList, index)
            break
        end
    end
end
function playerDataManager:SetPlayerEquipList(list)
    self.BagEquipList = list
end
function playerDataManager:GetPlayerEquipList()
    return self.BagEquipList    
end
return playerDataManager