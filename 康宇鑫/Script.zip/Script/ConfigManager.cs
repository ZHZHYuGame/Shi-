using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;
using Newtonsoft.Json;
[LuaCallCSharp]
public class ConfigManager : MonoBehaviour
{
    public List<GoodsData> goodsDatas = new List<GoodsData>();
    // Start is called before the first frame update
    public List<GoodsData> ReadJson()
    {
        goodsDatas = JsonConvert.DeserializeObject<List<GoodsData>>(Resources.Load<TextAsset>("inventoryConfig").text);
        return goodsDatas;  
        
    }
}
public class GoodsData
{
    public string id;
    public string name;
    public string icon;
    public string inventoryType;
    public string equipType;
    public string sale;
    public string starLevel;
    public string quality;
    public string damage;
    public string hp;
    public string power;
    public string Des;
}