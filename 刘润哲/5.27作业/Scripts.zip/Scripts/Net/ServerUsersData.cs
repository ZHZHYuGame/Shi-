using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ServerUsersData : Singleton<ServerUsersData>
{
    public Dictionary<int, UserData> userDict = new Dictionary<int, UserData>();
    /// <summary>
    /// ����һ���ͻ�����ҵ���Ϸ����
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    public UserData GetUser(int userId)
    {
        return userDict[userId];
    }
}
public class UserData
{
    public int userId;
    public int currTaskId;
}
