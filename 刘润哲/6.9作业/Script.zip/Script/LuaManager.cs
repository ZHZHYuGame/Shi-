using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using Unity.VisualScripting.Antlr3.Runtime.Tree;
using UnityEngine;
using UnityEngine.UI;
using XLua;

public class LuaManager : MonoBehaviour
{
    /// <summary>
    /// Lua�����
    /// </summary>
    LuaEnv luaEnv;
    //��ʼ����
    Action LuaStart;
    Action LuaUpdate;
    // Start is called before the first frame update
    void Start()
    {

        luaEnv = new LuaEnv();
        //���ر���Lua�ļ���ÿ�ζ�ȡLua�ű�ʱ������
        luaEnv.AddLoader(CustomLoaderHandle);
        //����Lua���ļ�����
        luaEnv.DoString("require'LuaMain'");
        //Lua��C#�ؼ�����ͬ����
        LuaStart= luaEnv.Global.GetInPath<Action>("LuaStart");
        LuaUpdate = luaEnv.Global.GetInPath<Action>("LuaUpdate");
        //ִ�д����󶨵ĺ���
        LuaStart?.Invoke();
    }
    /// <summary>
    /// ���ر���Lua�ļ���ÿ�ζ�ȡLua�ű�ʱ������
    /// </summary>
    /// <param name="filepath"></param>
    /// <returns></returns>
    /// <exception cref="NotImplementedException"></exception>
    private byte[] CustomLoaderHandle(ref string filepath)
    {
        return File.ReadAllBytes($"{Application.dataPath}/Script/LuaCode/{filepath}.lua");
    }

    // Update is called once per frame
    void Update()
    {
        LuaUpdate?.Invoke();
    }
}
[LuaCallCSharp]
public class TestLua
{
    public static void TestFunCShap()
    {
        //Debug.Log(1111111);
    }
    public void TestFunCShapTwo()
    {
        //Debug.Log(222222);
    }
    public void TestFunCShapThree()
    {
        //Debug.Log(333333);
    }
}
