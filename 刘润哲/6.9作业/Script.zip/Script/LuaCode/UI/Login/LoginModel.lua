--登录功能的数据层
local loginModel=BaseClass("loginModel")
--设置当前的记忆账号

function  loginModel:__init()
    
end
function  loginModel:SetAccount()
    
end
--设置当前的记忆密码
function  loginModel:SetPassword()
    
end
--获取当前的记忆账号
function  loginModel:GetAccount()
    
end
--获取当前的记忆密码
function  loginModel:GetPassword()
    
end


return loginModel