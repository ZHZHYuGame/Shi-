local loginView=BaseClass("loginView")
--初始化设置组件等
function loginView:__init(prefabObj)
    self.gameObject=prefabObj
    --组件获取
    self.input_Account=self.gameObject.transform:Find("Input_Account"):GetComponent("InputField")
    self.input_Password=self.gameObject.transform:Find("Input_Password"):GetComponent("InputField")
    --进入游戏按钮
    self.btn_GoGame=self.gameObject.transform:Find("Button"):GetComponent("Button")
    --记住账号密码的Toggle勾选框
    self.toggle_passwordremember=self.gameObject.transform:Find("Toggle_PasswordRemember"):GetComponent("Toggle")
end
--点击按钮 发送请求到服务器 进入游戏
function  loginView:GoGame()
    
end

--UI功能的事件注册
function loginView:AddListener()
    self.btn_GoGame.onClick.AddListener(self.GoGame)
end

--登录游戏
function  loginView:LoginGame()
    
end
-- function  loginView:PasswordRemember(text)
--     self.input_Password.text=text
-- end
return loginView