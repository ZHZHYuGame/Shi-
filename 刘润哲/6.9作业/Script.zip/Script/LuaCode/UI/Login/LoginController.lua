--登录功能的控制脚本  逻辑
local  loginController=BaseClass("loginController")

function  loginController:__init()
    self:AddEventListener()
    self:NetEventListener()
end

local function  clientHandle1()
    
end
--记录登录的密码
function loginController:PassWordRemember(txt)
    self.view.input_Password.text=txt
end
--客户端间事件交互
function loginController:AddEventListener()
    --MessageController:AddListener(ClientSystemEvent.ClientToClient1,clientHandle1)

    self.view.btn_GoGame.onClick:AddListener(function ()
        
    end)
    self.view.toggle_passwordremember.onValueChanged:AddListener(function ()
        self:loginController("fanfanfanfan")
    end)
end



--登录结果处理（来自服务器的网络消息）
--不对外开放
-- local function  LoginHandle1()
    
-- end
--对外开放
function  loginController:LoginHandle()
    --通过消息结果来判断是否登录成功
    --成功 进入游戏

    --失败 提示错误信息
end

--网络功能事件交互
function loginController:NetEventListener()
    -- MessageController:AddListener(NetMessageID.S2C_Login,function ()
        
    -- end)

    MessageController:AddListener(NetMessageID.S2C_Login,self.LoginHandle)
        
end
return loginController