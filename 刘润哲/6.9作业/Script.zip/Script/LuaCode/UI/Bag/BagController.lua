local bagController=BaseClass("bagController")

function bagController:InitBagItem()
    
    for i = 1, self.model.BagCell do
        local item=GameObject.Instantiate(Resources.Load("BagItem"),self.view.BagItemRoot.transform )
        if(i<self.model.list.Count) then
            
            -- item.transform:Find("icon/Name").gameObject:GetComponent("Text").text=self.model.list[i].name
            -- item.transform:Find("icon/Num").gameObject:GetComponent("Text").text=self.model.list[i].quality
            -- item.transform:Find("icon").gameObject:GetComponent("Image").sprite=Resources.Load("Icon/"..self.model.list[i].icon,typeof(CS.UnityEngine.Sprite))
            item=require("UI/Bag/BagViewItem").New(self.model.list[i],item)
            
        else
        -- local item=GameObject.Instantiate(Resources.Load("BagItem"),self.view.BagItemRoot.transform )
        -- item.transform:Find("icon").gameObject:GetComponent("Image").sprite=Resources.Load("Icon/bg_道具",typeof(CS.UnityEngine.Sprite))
        item=require("UI/Bag/BagViewItem").New(nil,item)
        end
    end
end
function  bagController:__init(...)
    local par={...}
    --self:TestData()
    
end


function bagController:ClientHandelType(list)
    print("客户端处理消息")
    if list~=nil then
        local refresh=require("UI/Bag/BagViewRefresh")
        refresh:ClearBagItem(self.view.BagItemRoot)

        for i = 1, self.model.BagCell do
        local item=GameObject.Instantiate(Resources.Load("BagItem"),self.view.BagItemRoot.transform )
        if(i<list.Count) then
            item=require("UI/Bag/BagViewItem").New(list[i],item)
            
        else
        item=require("UI/Bag/BagViewItem").New(nil,item)
        end
    end
    else
        print("背包列表为空，无法处理事件")
    end
    
end

local function onToggleChanged(isOn)
    if isOn then
        print("Toggle is on")
        -- 这里可以添加处理逻辑，比如筛选背包物品类型
        bagController.model:clientHandleBagType("全部")
    else
        print("Toggle is off")
    end
end

function bagController:ClientAddListener()

    MessageController:AddListener(ClientSystemEvent.ClientToBagType,ClientHandelType)
    MessageController:AddListener(ClientSystemEvent.ClientToClient1,function ()
        print("客户端监听消息1111111111 Client")
    end)

    if self.model.list~=nil then
        self:InitBagItem()
    end

    --self.view.allType.onValueChanged:AddListener(onToggleChanged)
    
end
function  bagController:Bag_Add_ViewShow()
    
end

--背包添加物品逻辑处理
function bagController:Bag_Add_Handle(gData)
    --添加一个物品信息
    --1.数据层已经刷新添加的物品到整体数据里
    self.model.BagAddData(gData)
    --2.通知View层显示出来，通过self.view 拿到相关的组件，进行赋值显示
    
end
--背包删除物品逻辑处理
function  bagController:Bag_Del_Handle()
    
end
--背包更新物品逻辑处理
function  bagController:Bag_Update_Handle()
    
end
--背包整理物品逻辑处理
function  bagController:Bag_Clean_Handle()
    
end

function  bagController:NetAddListener()
    -- MessageController:AddListeren(NetMessageID.Cl,function ()
    --     print("客户端监听消息1111111111Net")
    --     end)
    MessageController:AddListener(NetMessageID.S2C_Bag_Add,Bag_Add_Handle)
    MessageController:AddListener(NetMessageID.S2C_Bag_Del,Bag_Del_Handle)
    MessageController:AddListener(NetMessageID.S2C_Bag_Update,Bag_Update_Handle)
    MessageController:AddListener(NetMessageID.S2C_Bag_Clean,Bag_Clean_Handle)
end

function  bagController:__initFinish()
    self:ClientAddListener()
    self:NetAddListener()
end
return bagController