local bagView=BaseClass("bagView")

function bagView:__init(prefabObj)
    self.gameObject=prefabObj
    --组件获取
    self.BagItemRoot=self.gameObject.transform:Find("Scroll View/Viewport/BagItemRoot")
    self.allType=self.gameObject.transform:Find("TypeRoot/All"):GetComponent(" Toggle") 
    -- self.equipType=self.gameObject.transform.Find("TypeRoot/Equip"):GetComponent("Toggle")
    -- self.medicType=self.gameObject.transform.Find("TypeRoot/Medic"):GetComponent("Toggle")
    -- self.goldType=self.gameObject.transform.Find("TypeRoot/Gold"):GetComponent("Toggle")
end

return bagView