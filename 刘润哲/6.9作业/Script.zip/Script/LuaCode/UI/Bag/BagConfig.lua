--背包功能数据配置，来动态驱动整个功能的显示初始化（除面板界面的动态数据显示以外）
local bagConfig={
    --背包ID
    Id="bag",
    --背包面板显示层级
    Layer="UIWindowLayer",
    --背包控制C层脚本
    ControllerCode=require ("UI/Bag/BagController"),
    --背包模型M层脚本
    ModelCode=require ("UI/Bag/BagModel"),
    --背包视图V层脚本
    ViewCode=require ("UI/Bag/BagView"),
    --背包预制体名称
    PrefabName="Bag"
}

return bagConfig