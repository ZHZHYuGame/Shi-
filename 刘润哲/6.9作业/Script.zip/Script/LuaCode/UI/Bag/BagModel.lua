local bagModel=BaseClass("bagModel")
--背包数据层
-- 负责处理背包数据的逻辑
--1.初始化数据
--2.背包数据增加
--3.背包数据删除
--4.背包数据变化

function bagModel:__init()
  
  --角色的缓存里取背包的显示数据
  self.bagList=PlayerDataManager:GetBagList()

    local configManager=CS.ConfigManager()
    self.list = configManager:ReadJson()
    self.BagCell=30
end

function  bagModel:OnEnable()
  self.bagList=PlayerDataManager:GetBagList()
end
--背包添加物品数据
function  bagModel:BagAdddata(gData)
  
end

function  bagModel:BagUpDataData()
  
end
function  bagModel:AddListener()
  
end

function bagModel:clientHandleBagType(txt)
    typeList={}
    if self.list~=nil then
        -- 这里可以添加处理逻辑，比如筛选背包物品类型
        if txt == "全部" then
          for i = 1, self.list.Count do
            typeList.Add(self.list[i])
            MessageController:DisPath(ClientSystemEvent.ClientToBagType,typeList)
          end
        else
            print("背包列表为空，无法处理事件")
        end
    end
end

return bagModel