NetMessageID={
    --登录
    C2S_Login = 101, --登录请求
    S2C_Login = 102, --登录返回

    --背包模块
    --C2S_Bag_Info=103, --请求背包信息数据
    --C2S_Bag_Add = 103, --添加背包物品（服务器计算得知物品告诉客户端）
    S2C_Bag_Add = 104, --添加背包物品返回
    C2S_Bag_Del=105, --删除背包物品
    S2C_Bag_Del=106, --删除背包物品返回
    C2S_Bag_Update=107, --更新背包物品
    S2C_Bag_Update=108, --更新背包物品返回、
    C2S_Bag_Clean=109,
    S2C_Bag_Clean=110, --清空背包物品返回
}