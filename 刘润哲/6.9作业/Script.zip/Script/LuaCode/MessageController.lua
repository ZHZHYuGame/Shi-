local messageController={}
local actionDict={}
--消息中心事件注册
--ID 消息号
--action==function
function messageController:AddListener(id,action)
    if self.actionList==nil then
        self.actionList={}
    end
    --把消息管理起来，模拟实现多播统一管理
    table.insert(self.actionList,action)
    actionDict[id]=self.actionList
end
--消息中心事件派发
function messageController:DisPath(id,...)
    --获取id的事件列表
    local aList=actionDict[id]
    --如果时间列表存在
if aList~=nil then
        for index, value in ipairs(aList) do
            --所有事件进行逐一执行，模拟多播的全部执行
            value(...)
        end
    end
end

function messageController:RemoveListener(id,action)
    --获取id的事件列表
    local aList=actionDict[id]
    if aList~=nil then
        for index, value in ipairs(aList) do
            if value==action then
                table.remove(aList,index)
                break
            end
        end
    end
end
return messageController