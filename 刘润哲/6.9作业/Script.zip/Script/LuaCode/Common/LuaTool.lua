LuaTool={}
--闭包绑定
function LuaTool.Bind(self,fun,...)
    -- function aa()
    --     return fun(self)
    -- end
    --aa()

    --fun(self)
    local params=nil
    if self==nil then
        params=SafePack(...)
    else
        params=safePack(self,...)
    end
    return function (...)
        local args=ConcatSafePack(params,SafePack(...))
        fun(SafeUppack(args)) 
    end
end