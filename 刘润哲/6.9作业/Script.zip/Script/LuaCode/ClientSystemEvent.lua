ClientSystemEvent={
    ClientToClient1="ClientToClient1",
    ClientToClient2="ClientToClient2",
    ClientToClient3="ClientToClient3",
    ClientToClient4="ClientToClient4",
    ClientToClient5="ClientToClient5",
    ClientToBagType="ClientToBagType",
}