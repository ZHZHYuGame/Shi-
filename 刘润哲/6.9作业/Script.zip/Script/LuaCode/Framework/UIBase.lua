local uiBase=BaseClass("uiBase")
function  uiBase:Show()
    print("uiBase:Close()")
end
function  uiBase:Close()
    
end

return uiBase