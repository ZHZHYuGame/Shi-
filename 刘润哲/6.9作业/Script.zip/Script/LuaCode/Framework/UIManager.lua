
--模拟对象
local uiManager = BaseClass("uiManager")
local uiName="UIManager"
uiManager.uiName="uiManager"

function uiManager:__init()
    print("UI框架的执行")
    --UI字典管理
    self.UIDict={}
    --UI打开顺序记忆栈
    self.UIStack={}
    --UI预制体的父级对象
    self.canvasParent=GameObject.Find("Canvas")
end

--打开UI方法1
--全局方法，只有在全局需要的时候才会在特殊位置这样写
-- function OpenUI(id)
    
-- end
--打开UI方法2
--结构是上面模拟的对象.方法
-- function uiManager.OpenUI(id)
--     --print("self=",self,"id=",id)
-- end

function uiManager:GetLayerToCanvas(layer)
    return GameObject.Find(layer)
end
--打开UI方法3
--结构是上面模拟的对象:方法
function uiManager:OpenUI(id,...)
    -- self.uiName="UIManagerInstance"
    --print("self=",self,"id=",id)

    --1.加载UI预制体
    --[[if self.UIDict[id]==nil then
        --加载预制体对象
        local uiPrefab =GameObject.Instantiate(Resources.Load(UI_Prefab_Path_Title..id),self.canvasParent.transform)
       --对应UI功能的脚本加载，Model/View/Controller
        --local uiLuaCode= require("UI/"..id.."/"..id.."Code")
        local loginController = require("UI/"..id.."/"..id.."Controller")
        local loginModel = require("UI/"..id.."/"..id.."Model")
        local loginView = require("UI/"..id.."/"..id.."View")
        loginController=loginController.New()
        loginController.model=loginModel.New()
        --对应UI脚本注册预制件绑定
        --uiLuaCode.New(uiPrefab) 
        loginController.view=loginView.New(uiPrefab)
        --UI所处于的显示层

        --加载对应UI的Lua Code
        self.UIDict[id]=uiPrefab
    end]]--
    if self.UIDict[id]==nil then
        local config= require ("UI/"..id.."/"..id.."Config")
        local uiPrefab=GameObject.Instantiate(Resources.Load(UI_Prefab_Path_Title..config.PrefabName),self:GetLayerToCanvas(config.Layer).transform)
        config.ControllerCode=config.ControllerCode.New(...)
        config.ControllerCode.model=config.ModelCode.New()
        config.ControllerCode.view=config.ViewCode.New(uiPrefab)
        --模块导入完成
        config.ControllerCode:__initFinish()

        --加载对应UI的Lua Code
        self.UIDict[id]=config
        
    end


    
    
end
-- local function OpenUI1()
--     --print("OpenUI11111")
-- end

function uiManager:GetUI()
    
end
function uiManager:CloseUI(id)
    if self.UIDict[id]~=nil then
        --查询预制体对象
        local uiPrefab =GameObject.Find(id.."(Clone)")
        if uiPrefab then
            --销毁预制体对象
            GameObject.Destroy(uiPrefab)
            self.UIDict[id]=nil
        else
            print("没有找到对应的UI预制体对象")
        end
    end
end
--获取UI所在的Canvas层级


--uiManager.OpenUI1=OpenUI1
return uiManager