uiEnum={
    Login="Login",
    Chat="Chat",
    Bag="Bag"
}