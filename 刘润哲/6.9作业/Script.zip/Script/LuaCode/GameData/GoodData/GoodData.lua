local goodData=BaseClass("GoodData")

function  goodData:__init(...)
    local preTab={...}
    self.goodId=preTab[1]
    self.goodName=preTab[2]
    self.goodType=preTab[3]
    self.goodQuality=preTab[4]
    self.goodIcon=preTab[5]
end

return goodData

