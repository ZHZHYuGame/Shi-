local goodDataManager={}

--初始化数据
function goodDataManager:__init()
    self.goodDict={}
    --读取配置表，json

end

--动态设置数据
function  goodDataManager:SetGoodData(id,...)
    
end

--获取一个物品数据
function goodDataManager:GetGoodData(id)
    return self.goodDict[id] 
end

--获取一个物品的品质
function goodDataManager:GetGoodQuality(id)
    return self.goodDict[id].quality
end

--获取一个物品的价格
function goodDataManager:GetGoodPrice(id)
    return self.goodDict[id].price
end

return goodDataManager