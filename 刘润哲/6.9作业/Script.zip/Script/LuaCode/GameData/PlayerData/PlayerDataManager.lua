--缓存角色的一部分游戏数据
playerDataManager={}

function playerDataManager:__init(...)
    local par={...}
    self.BagList={}
    self.PlayerEquipList={}
    self.MedicineList={}
    self.SkillList={}
    self.MailList={}
end



function  playerDataManager:SetBagList(list)
    self.BagList=list
end
function  playerDataManager:GetBagList(list)
    return self.BagList
end
--添加缓存中的物品
function playerDataManager:AddBagData(gData)
    table.insert(self.BagList,gData)
end
--删除缓存中的物品
function playerDataManager:DelBagData(gridId)
    for index, value in ipairs(self.BagList) do
        if index == gridId then
            table.remove(self.BagList,index)
            break
        end
    end
    
end
function  playerDataManager:SetPlayerEquipList(list)
    self.PlayerEquipList=list
end
function  playerDataManager:GetPlayerEquipList(list)
    return self.PlayerEquipList
end
return playerDataManager