using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class UIEventListener : EventTrigger
{
    Dictionary<int, Action<GameObject>> dict = new Dictionary<int, Action<GameObject>>();
    public static UIEventListener AddObjEvent(GameObject obj)
    {
        UIEventListener u = obj.GetComponent<UIEventListener>();
        if (!u)
        {
            u = obj.AddComponent<UIEventListener>();
        }
        return u;
    }
    public void AddEventListeren(int id, Action<GameObject> act)
    {
        if (!dict.ContainsKey(id))
        {
            dict.Add(id, act);
        }
    }
    public override void OnPointerClick(PointerEventData eventData)
    {
        if (dict.ContainsKey((int)EventTriggerType.PointerClick))
        {
            dict[(int)EventTriggerType.PointerClick]?.Invoke(eventData.pointerClick);
        }
    }
    public override void OnPointerExit(PointerEventData eventData)
    {
        base.OnPointerExit(eventData);
    }
    public override void OnPointerEnter(PointerEventData eventData)
    {
        base.OnPointerEnter(eventData);
    }
    public override void OnBeginDrag(PointerEventData eventData)
    {
        if (dict.ContainsKey((int)EventTriggerType.BeginDrag))
        {
            dict[(int)EventTriggerType.BeginDrag]?.Invoke(eventData.pointerDrag);
        }
    }
    public override void OnDrag(PointerEventData eventData)
    {
        if (dict.ContainsKey((int)EventTriggerType.Drag))
        {
            dict[(int)EventTriggerType.Drag]?.Invoke(eventData.pointerDrag);
        }
    }
    public override void OnEndDrag(PointerEventData eventData)
    {
        if (dict.ContainsKey((int)EventTriggerType.EndDrag))
        {
            dict[(int)EventTriggerType.EndDrag]?.Invoke(eventData.pointerCurrentRaycast.gameObject);
            
        }
    }
}