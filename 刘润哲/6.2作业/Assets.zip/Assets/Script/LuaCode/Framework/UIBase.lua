local uiBase=BaseClass("uiBase")
function  uiBase:OpenUI()
    
end
function  uiBase:CloseUI()
    
end

return uiBase