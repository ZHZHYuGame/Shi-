local chatCode=BaseClass("chatCode",uiBase)

function  chatCode:__init(obj)
    --进入功能的预制件绑定
    self.gameObject=obj
    self.input_Message=self.gameObject.transform:Find("Message"):GetComponent("InputField")
    self.btn_Send=self.gameObject.transform:Find("send"):GetComponent("Button")
    self.btn_Send.onClick:AddListener(function ()
        print("点击了发送按钮")
        local message=self.input_Message.text
        if message==""  then
            print("发送内容不能为空")
            return
        end
        --发送登录请求
        print("发送内容=",message)
    end)
end
return chatCode