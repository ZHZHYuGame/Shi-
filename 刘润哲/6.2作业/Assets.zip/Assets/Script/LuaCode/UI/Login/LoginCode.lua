local loginCode=BaseClass("loginCode",uiBase)

function  loginCode:__init(obj)
    --print("Login self=",self,"obj=",obj)
    --进入功能的预制件绑定
    self.gameObject=obj
    self.input_Account=self.gameObject.transform:Find("Input_Account"):GetComponent("InputField")
    self.input_Password=self.gameObject.transform:Find("Input_Password"):GetComponent("InputField")
    self.btn_GoGame=self.gameObject.transform:Find("Button"):GetComponent("Button")
    self.btn_GoGame.onClick:AddListener(function ()
        --print("点击了进入游戏按钮")
        local account=self.input_Account.text
        local password=self.input_Password.text
        if account=="" or password=="" then
            print("账号或密码不能为空")
            return
        end
        --发送登录请求
        print("账号=",account,"密码=",password)
        local uMgr=require("Framework/UIManager")
        UIManager=uMgr.New()
        UIManager:CloseUI(uiEnum.Login)
        UIManager:OpenUI(uiEnum.Chat)
    end)
end
return loginCode