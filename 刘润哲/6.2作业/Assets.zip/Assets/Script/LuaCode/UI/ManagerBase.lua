local managerBase={}
function managerBase:MessageController()
    
end

function managerBase:AddEventListener()
    
end

return managerBase